#target illustrator

var CHAPPY_DIMENSION_STYLE_V03Test = {
    layerName: "寸法線",
    generatedItemNote: "com.chappy.dimension_v0_3:generated",
    legacyGeneratedItemNotes: [
        "com.chappy.dimension_v0_3_test:generated"
    ],
    offsetMm: 12,
    objectGapMm: 3,
    textGapMm: 2,
    scaleGapMm: 7,
    endpointDiameterMm: 0.64,
    strokeWidthPt: 0.25,
    fontSizePt: 10,
    preferredFont: "KozGoPr6N-Regular"
};

function createDimensionsV03Test(
    scale,
    showTop,
    showBottom,
    showLeft,
    showRight,
    showScale,
    magnification,
    detectionMode,
    roundingMode,
    deleteSelected,
    fontName,
    fontSizePt
) {
    var document;
    var originalActiveLayer;
    var selectedItems;
    var bounds;
    var dimensionLayer;
    var style;
    var group;
    var createdGroups = [];
    var widthLabel;
    var heightLabel;
    var detectionItems;
    var detectionBounds;
    var containment;
    var created = [];
    var deletionResult;

    try {
        if (app.documents.length === 0) {
            return "エラー: ドキュメントが開かれていません。";
        }

        document = app.activeDocument;
        originalActiveLayer = document.activeLayer;
        selectedItems = copySelectionV03Test(document.selection);

        if (selectedItems.length === 0) {
            return "エラー: 寸法を測るオブジェクトを選択してください。";
        }
        if (!isFinite(scale) || scale <= 0 || Math.floor(scale) !== scale) {
            return "エラー: スケールには1以上の整数を指定してください。";
        }
        if (!isFinite(magnification) || magnification <= 0) {
            return "エラー: 拡大率には0より大きい数値を指定してください。";
        }
        if (!fontName) {
            fontName = CHAPPY_DIMENSION_STYLE_V03Test.preferredFont;
        }
        if (fontSizePt === undefined || fontSizePt === null || fontSizePt === "") {
            fontSizePt = CHAPPY_DIMENSION_STYLE_V03Test.fontSizePt * magnification;
        }
        fontSizePt = Number(fontSizePt);
        if (!isFinite(fontSizePt) || fontSizePt <= 0) {
            return "エラー: フォントサイズには0より大きい数値を指定してください。";
        }
        if (roundingMode !== "none" &&
                roundingMode !== "floor" &&
                roundingMode !== "round") {
            return "エラー: 寸法値の端数処理が正しくありません。";
        }
        if (detectionMode !== "none" &&
                detectionMode !== "children" &&
                detectionMode !== "containment") {
            return "エラー: 連立寸法の検知方法が正しくありません。";
        }
        if (!showTop && !showBottom && !showLeft && !showRight && !showScale) {
            return "エラー: 作成する項目が選択されていません。";
        }
        if (detectionMode === "children" &&
                !showTop && !showBottom && !showLeft && !showRight) {
            return "エラー: 下層レイヤーの連立寸法には上・下・左・右のいずれかが必要です。";
        }

        bounds = getCombinedGeometricBoundsV03Test(selectedItems);

        if (detectionMode !== "none") {
            detectionItems = getDetectionItemsV03Test(selectedItems);

            if (detectionItems.length < 2) {
                return "エラー: 検知できる項目が2個以上必要です。";
            }
            if (detectionItems.length >= 15) {
                return "エラー: 仮想グループが15個以上です。最大14個までにしてください。";
            }

            detectionBounds = getCombinedGeometricBoundsV03Test(detectionItems);

            if (detectionMode === "children") {
                bounds = detectionBounds;
            } else {
                containment = detectContainmentV03Test(detectionItems);
                if (!containment) {
                    return "エラー: 外形が内形を囲む内包関係を検知できません。";
                }
                bounds = containment.outerBounds;
            }
        }

        widthLabel = formatDimensionValueV03Test(
            pointsToMillimetersV03Test(bounds.right - bounds.left) * scale,
            roundingMode
        );
        heightLabel = formatDimensionValueV03Test(
            pointsToMillimetersV03Test(bounds.top - bounds.bottom) * scale,
            roundingMode
        );
        style = getScaledDimensionStyleV03Test(magnification, fontName, fontSizePt);
        dimensionLayer = getOrCreateDimensionLayerV03Test(document);
        document.activeLayer = dimensionLayer;

        if (showTop) {
            group = dimensionLayer.groupItems.add();
            markGeneratedDimensionGroupV03Test(group);
            createdGroups.push(group);

            if (detectionMode === "children") {
                group.name = "上側 連立寸法 合計 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createChainHorizontalDimensionV03Test(
                    group,
                    getItemsLeftToRightV03Test(detectionItems),
                    detectionBounds,
                    widthLabel,
                    scale,
                    roundingMode,
                    "top",
                    style
                );
                created.push(
                    "上側 連立 " + detectionItems.length +
                    "項目 / 合計 " + widthLabel
                );
            } else if (detectionMode === "containment") {
                group.name = "上側 内包寸法 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createContainmentHorizontalDimensionV03Test(
                    group,
                    containment,
                    scale,
                    roundingMode,
                    "top",
                    style
                );
                created.push("上側 内包寸法 / 外形 " + widthLabel);
            } else {
                group.name = "上側 横寸法 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createHorizontalDimensionV03Test(
                    group,
                    bounds,
                    widthLabel,
                    "top",
                    style
                );
                created.push("上側 よこ " + widthLabel);
            }
        }

        if (showBottom) {
            group = dimensionLayer.groupItems.add();
            markGeneratedDimensionGroupV03Test(group);
            createdGroups.push(group);

            if (detectionMode === "children") {
                group.name = "下側 連立寸法 合計 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createChainHorizontalDimensionV03Test(
                    group,
                    getItemsLeftToRightV03Test(detectionItems),
                    detectionBounds,
                    widthLabel,
                    scale,
                    roundingMode,
                    "bottom",
                    style
                );
                created.push(
                    "下側 連立 " + detectionItems.length +
                    "項目 / 合計 " + widthLabel
                );
            } else if (detectionMode === "containment") {
                group.name = "下側 内包寸法 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createContainmentHorizontalDimensionV03Test(
                    group,
                    containment,
                    scale,
                    roundingMode,
                    "bottom",
                    style
                );
                created.push("下側 内包寸法 / 外形 " + widthLabel);
            } else {
                group.name = "下側 横寸法 " + widthLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "horizontal",
                    scale,
                    roundingMode
                );
                createHorizontalDimensionV03Test(
                    group,
                    bounds,
                    widthLabel,
                    "bottom",
                    style
                );
                created.push("下側 よこ " + widthLabel);
            }
        }

        if (showLeft) {
            group = dimensionLayer.groupItems.add();
            markGeneratedDimensionGroupV03Test(group);
            createdGroups.push(group);

            if (detectionMode === "children") {
                group.name = "左側 連立寸法 合計 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createChainVerticalDimensionV03Test(
                    group,
                    getItemsTopToBottomV03Test(detectionItems),
                    detectionBounds,
                    heightLabel,
                    scale,
                    roundingMode,
                    "left",
                    style
                );
                created.push(
                    "左側 連立 " + detectionItems.length +
                    "項目 / 合計 " + heightLabel
                );
            } else if (detectionMode === "containment") {
                group.name = "左側 内包寸法 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createContainmentVerticalDimensionV03Test(
                    group,
                    containment,
                    scale,
                    roundingMode,
                    "left",
                    style
                );
                created.push("左側 内包寸法 / 外形 " + heightLabel);
            } else {
                group.name = "左側 縦寸法 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createVerticalDimensionV03Test(
                    group,
                    bounds,
                    heightLabel,
                    "left",
                    style
                );
                created.push("左側 たて " + heightLabel);
            }
        }

        if (showRight) {
            group = dimensionLayer.groupItems.add();
            markGeneratedDimensionGroupV03Test(group);
            createdGroups.push(group);

            if (detectionMode === "children") {
                group.name = "右側 連立寸法 合計 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createChainVerticalDimensionV03Test(
                    group,
                    getItemsTopToBottomV03Test(detectionItems),
                    detectionBounds,
                    heightLabel,
                    scale,
                    roundingMode,
                    "right",
                    style
                );
                created.push(
                    "右側 連立 " + detectionItems.length +
                    "項目 / 合計 " + heightLabel
                );
            } else if (detectionMode === "containment") {
                group.name = "右側 内包寸法 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createContainmentVerticalDimensionV03Test(
                    group,
                    containment,
                    scale,
                    roundingMode,
                    "right",
                    style
                );
                created.push("右側 内包寸法 / 外形 " + heightLabel);
            } else {
                group.name = "右側 縦寸法 " + heightLabel;
                setGeneratedDimensionMetadataV03Test(
                    group,
                    "dimension",
                    "vertical",
                    scale,
                    roundingMode
                );
                createVerticalDimensionV03Test(
                    group,
                    bounds,
                    heightLabel,
                    "right",
                    style
                );
                created.push("右側 たて " + heightLabel);
            }
        }

        if (showScale) {
            group = dimensionLayer.groupItems.add();
            markGeneratedDimensionGroupV03Test(group);
            group.name = "スケール表記 1:" + scale;
            setGeneratedDimensionMetadataV03Test(
                group,
                "scale",
                "label",
                scale,
                roundingMode
            );
            createdGroups.push(group);
            createScaleLabelV03Test(
                group,
                bounds,
                "Scale 1:" + scale,
                style,
                showRight
            );
            created.push("Scale 1:" + scale);
        }

        if (deleteSelected) {
            deletionResult = removeSelectedItemsV03Test(selectedItems);
            created.push(
                "選択オブジェクトを削除 " + deletionResult.deleted + "件"
            );
            if (deletionResult.failed > 0) {
                created.push(
                    "削除できなかったオブジェクト " +
                    deletionResult.failed +
                    "件"
                );
            }
        } else {
            restoreSelectionV03Test(document, selectedItems);
        }
        restoreActiveLayerV03Test(document, originalActiveLayer);
        app.redraw();

        return "作成しました\n" + created.join("\n") +
            "\n拡大率: x" + formatNumberV03Test(magnification) +
            "\nフォント: " + getFontDisplayNameV03Test(style.fontName) +
            " / " + formatNumberV03Test(style.fontSizePt) + " pt" +
            "\n端数処理: " + getRoundingLabelV03Test(roundingMode) +
            "\n単位: mm";
    } catch (error) {
        removeCreatedGroupsV03Test(createdGroups);
        if (document && selectedItems) {
            restoreSelectionV03Test(document, selectedItems);
        }
        if (document && originalActiveLayer) {
            restoreActiveLayerV03Test(document, originalActiveLayer);
        }
        return "エラー: " + error.message + " (line " + error.line + ")";
    }
}

function updateSelectedDimensionValuesV03Test() {
    var document;
    var selectedItems;
    var groups;
    var plans = [];
    var plan;
    var updatedCount = 0;
    var scaleSummary = [];
    var roundingSummary = [];
    var i;
    var j;

    try {
        if (app.documents.length === 0) {
            return "エラー: ドキュメントが開かれていません。";
        }

        document = app.activeDocument;
        selectedItems = copySelectionV03Test(document.selection);
        if (selectedItems.length === 0) {
            return "エラー: 更新する寸法グループを選択してください。";
        }

        groups = getSelectedDimensionGroupsForUpdateV03Test(selectedItems);
        if (groups.length === 0) {
            return "エラー: このツールで作成した寸法グループを選択してください。";
        }

        for (i = 0; i < groups.length; i += 1) {
            plan = createDimensionValueUpdatePlanV03Test(groups[i]);
            plans.push(plan);
            addUniqueTextValueV03Test(scaleSummary, "1:" + plan.scale);
            addUniqueTextValueV03Test(
                roundingSummary,
                getRoundingLabelV03Test(plan.roundingMode)
            );
        }

        for (i = 0; i < plans.length; i += 1) {
            for (j = 0; j < plans[i].updates.length; j += 1) {
                plans[i].updates[j].textFrame.contents = plans[i].updates[j].value;
                centerPageItemAtV03Test(
                    plans[i].updates[j].textFrame,
                    plans[i].updates[j].center.x,
                    plans[i].updates[j].center.y
                );
                updatedCount += 1;
            }
        }

        return "数値を更新しました" +
            "\n対象: " + groups.length + "グループ" +
            "\n更新: " + updatedCount + "項目" +
            "\nScale: " + scaleSummary.join(", ") +
            "\n端数処理: " + roundingSummary.join(", ") +
            "\n単位: mm";
    } catch (error) {
        return "エラー: " + error.message + " (line " + error.line + ")";
    }
}

function getScaledDimensionStyleV03Test(magnification, fontName, fontSizePt) {
    var selectedFontName = fontName || CHAPPY_DIMENSION_STYLE_V03Test.preferredFont;

    return {
        offsetMm: CHAPPY_DIMENSION_STYLE_V03Test.offsetMm * magnification,
        objectGapMm: CHAPPY_DIMENSION_STYLE_V03Test.objectGapMm * magnification,
        textGapMm: CHAPPY_DIMENSION_STYLE_V03Test.textGapMm * magnification,
        tierGapMm:
            CHAPPY_DIMENSION_STYLE_V03Test.offsetMm * 0.75 * magnification,
        scaleGapMm: CHAPPY_DIMENSION_STYLE_V03Test.scaleGapMm * magnification,
        endpointDiameterMm:
            CHAPPY_DIMENSION_STYLE_V03Test.endpointDiameterMm * magnification,
        strokeWidthPt:
            CHAPPY_DIMENSION_STYLE_V03Test.strokeWidthPt * magnification,
        fontName: selectedFontName,
        fontSizePt: fontSizePt
    };
}

function getDetectionItemsV03Test(selectedItems) {
    var items = [];
    var parentGroup;
    var item;
    var i;

    if (selectedItems.length === 1 &&
            selectedItems[0].typename === "GroupItem") {
        parentGroup = selectedItems[0];
        if (isGeneratedDimensionItemV03Test(parentGroup)) {
            return items;
        }
        for (i = 0; i < parentGroup.pageItems.length; i += 1) {
            item = parentGroup.pageItems[i];
            if (isDirectChildV03Test(item, parentGroup) &&
                    isEligibleDetectionItemV03Test(item)) {
                items.push(item);
            }
        }
        return items;
    }

    for (i = 0; i < selectedItems.length; i += 1) {
        if (isEligibleDetectionItemV03Test(selectedItems[i])) {
            items.push(selectedItems[i]);
        }
    }
    return items;
}

function isDirectChildV03Test(item, parentGroup) {
    try {
        return item.parent === parentGroup;
    } catch (error) {
        return true;
    }
}

function isEligibleDetectionItemV03Test(item) {
    try {
        if (item.hidden || item.locked) {
            return false;
        }
        if (item.typename === "PathItem" && item.guides) {
            return false;
        }
        if (isGeneratedDimensionItemV03Test(item)) {
            return false;
        }
        return item.geometricBounds[2] > item.geometricBounds[0] ||
            item.geometricBounds[1] > item.geometricBounds[3];
    } catch (error) {
        return false;
    }
}

function markGeneratedDimensionGroupV03Test(group) {
    try {
        group.note = CHAPPY_DIMENSION_STYLE_V03Test.generatedItemNote;
    } catch (error) {
        // The group name check remains available on older Illustrator versions.
    }
}

function setGeneratedDimensionMetadataV03Test(
    group,
    kind,
    orientation,
    scale,
    roundingMode
) {
    var note = CHAPPY_DIMENSION_STYLE_V03Test.generatedItemNote +
        "\nkind=" + kind +
        ";orientation=" + orientation +
        ";scale=" + String(scale) +
        ";rounding=" + roundingMode;

    try {
        group.note = note;
    } catch (error) {
        // The group name check remains available on older Illustrator versions.
    }
}

function getGeneratedDimensionNotePrefixV03Test(note) {
    var text = String(note || "");
    var prefixes = [CHAPPY_DIMENSION_STYLE_V03Test.generatedItemNote];
    var legacyPrefixes = CHAPPY_DIMENSION_STYLE_V03Test.legacyGeneratedItemNotes || [];
    var prefix;
    var i;

    for (i = 0; i < legacyPrefixes.length; i += 1) {
        prefixes.push(legacyPrefixes[i]);
    }

    for (i = 0; i < prefixes.length; i += 1) {
        prefix = prefixes[i];
        if (text === prefix ||
                text.indexOf(prefix + "\n") === 0 ||
                text.indexOf(prefix + "\r\n") === 0) {
            return prefix;
        }
    }
    return "";
}

function isGeneratedDimensionNoteV03Test(note) {
    return getGeneratedDimensionNotePrefixV03Test(note) !== "";
}

function getGeneratedDimensionMetadataV03Test(group) {
    var metadata = {
        kind: "",
        orientation: "",
        scale: NaN,
        roundingMode: ""
    };
    var note;
    var prefix;
    var data;
    var parts;
    var pair;
    var key;
    var value;
    var separatorIndex;
    var i;

    try {
        note = String(group.note || "");
    } catch (error) {
        note = "";
    }
    if (!isGeneratedDimensionNoteV03Test(note)) {
        return null;
    }

    prefix = getGeneratedDimensionNotePrefixV03Test(note);
    data = note.substring(prefix.length);
    data = data.replace(/^\r?\n/, "");
    if (!data) {
        return metadata;
    }

    parts = data.split(";");
    for (i = 0; i < parts.length; i += 1) {
        pair = parts[i];
        separatorIndex = pair.indexOf("=");
        if (separatorIndex < 0) {
            continue;
        }
        key = pair.substring(0, separatorIndex);
        value = pair.substring(separatorIndex + 1);

        if (key === "kind") {
            metadata.kind = value;
        } else if (key === "orientation") {
            metadata.orientation = value;
        } else if (key === "scale") {
            metadata.scale = Number(value);
        } else if (key === "rounding") {
            metadata.roundingMode = value;
        }
    }
    return metadata;
}

function getSelectedDimensionGroupsForUpdateV03Test(selectedItems) {
    var groups = [];
    var group;
    var i;

    for (i = 0; i < selectedItems.length; i += 1) {
        group = findGeneratedDimensionGroupForUpdateV03Test(selectedItems[i]);
        if (group && !containsPageItemV03Test(groups, group)) {
            groups.push(group);
        }
    }
    return groups;
}

function findGeneratedDimensionGroupForUpdateV03Test(item) {
    var current = item;
    var name;

    while (current) {
        try {
            if (current.typename === "GroupItem") {
                if (isGeneratedDimensionNoteV03Test(current.note)) {
                    return current;
                }
                name = String(current.name || "");
                if (isGeneratedDimensionGroupNameV03Test(name)) {
                    return current;
                }
            }
        } catch (error) {
            // Continue checking parent groups.
        }

        try {
            current = current.parent;
            if (!current ||
                    current.typename === "Layer" ||
                    current.typename === "Document") {
                break;
            }
        } catch (parentError) {
            break;
        }
    }
    return null;
}

function containsPageItemV03Test(items, targetItem) {
    var i;

    for (i = 0; i < items.length; i += 1) {
        if (items[i] === targetItem) {
            return true;
        }
    }
    return false;
}

function createDimensionValueUpdatePlanV03Test(group) {
    var metadata = getGeneratedDimensionMetadataV03Test(group);
    var lines;
    var texts;
    var usedLineIndexes = [];
    var updates = [];
    var text;
    var lineIndex;
    var line;
    var value;
    var i;

    validateDimensionUpdateMetadataV03Test(group, metadata);

    lines = collectDimensionLinesV03Test(group, metadata.orientation);
    texts = collectDimensionTextFramesV03Test(group);

    if (lines.length === 0) {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」の寸法線を検出できません。"
        );
    }
    if (texts.length !== lines.length) {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」の線数と数値テキスト数が一致しません。"
        );
    }

    for (i = 0; i < texts.length; i += 1) {
        text = texts[i];
        lineIndex = findNearestUnusedDimensionLineV03Test(
            text,
            lines,
            usedLineIndexes,
            metadata.orientation
        );
        if (lineIndex < 0) {
            throw new Error(
                "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
                "」の数値テキストと寸法線を対応付けできません。"
            );
        }
        usedLineIndexes.push(lineIndex);
        line = lines[lineIndex];
        value = formatDimensionValueV03Test(
            pointsToMillimetersV03Test(line.lengthPt) * metadata.scale,
            metadata.roundingMode
        );
        updates.push({
            textFrame: text,
            value: value,
            center: getPageItemCenterV03Test(text)
        });
    }

    return {
        group: group,
        scale: metadata.scale,
        roundingMode: metadata.roundingMode,
        updates: updates
    };
}

function validateDimensionUpdateMetadataV03Test(group, metadata) {
    if (!metadata) {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」はこのツールの寸法として認識できません。"
        );
    }
    if (!metadata.kind) {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」には更新用情報がありません。新しく作成した寸法で試してください。"
        );
    }
    if (metadata.kind !== "dimension") {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」は数値更新の対象ではありません。"
        );
    }
    if (metadata.orientation !== "horizontal" &&
            metadata.orientation !== "vertical") {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」の向き情報を読み取れません。"
        );
    }
    if (!isFinite(metadata.scale) ||
            metadata.scale <= 0 ||
            Math.floor(metadata.scale) !== metadata.scale) {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」のスケール情報を読み取れません。"
        );
    }
    if (metadata.roundingMode !== "none" &&
            metadata.roundingMode !== "floor" &&
            metadata.roundingMode !== "round") {
        throw new Error(
            "寸法グループ「" + getPageItemDisplayNameV03Test(group) +
            "」の端数処理情報を読み取れません。"
        );
    }
}

function collectDimensionLinesV03Test(group, orientation) {
    var lines = [];
    var pathItems = group.pathItems;
    var line;
    var i;

    for (i = 0; i < pathItems.length; i += 1) {
        line = getDimensionLineInfoV03Test(pathItems[i], orientation);
        if (line) {
            lines.push(line);
        }
    }
    return lines;
}

function getDimensionLineInfoV03Test(pathItem, orientation) {
    var tolerance = 0.2;
    var minimumLength = 1;
    var pointA;
    var pointB;
    var x1;
    var y1;
    var x2;
    var y2;
    var lengthPt;

    try {
        if (pathItem.guides ||
                pathItem.clipping ||
                pathItem.pathPoints.length !== 2) {
            return null;
        }
        pointA = pathItem.pathPoints[0].anchor;
        pointB = pathItem.pathPoints[1].anchor;
    } catch (error) {
        return null;
    }

    x1 = Number(pointA[0]);
    y1 = Number(pointA[1]);
    x2 = Number(pointB[0]);
    y2 = Number(pointB[1]);

    if (orientation === "horizontal") {
        lengthPt = Math.abs(x2 - x1);
        if (Math.abs(y1 - y2) > tolerance || lengthPt <= minimumLength) {
            return null;
        }
    } else {
        lengthPt = Math.abs(y1 - y2);
        if (Math.abs(x1 - x2) > tolerance || lengthPt <= minimumLength) {
            return null;
        }
    }

    return {
        pathItem: pathItem,
        x1: x1,
        y1: y1,
        x2: x2,
        y2: y2,
        minX: Math.min(x1, x2),
        maxX: Math.max(x1, x2),
        minY: Math.min(y1, y2),
        maxY: Math.max(y1, y2),
        centerX: (x1 + x2) / 2,
        centerY: (y1 + y2) / 2,
        lengthPt: lengthPt
    };
}

function collectDimensionTextFramesV03Test(group) {
    var texts = [];
    var i;

    for (i = 0; i < group.textFrames.length; i += 1) {
        texts.push(group.textFrames[i]);
    }
    return texts;
}

function findNearestUnusedDimensionLineV03Test(
    textFrame,
    lines,
    usedLineIndexes,
    orientation
) {
    var textCenter = getPageItemCenterV03Test(textFrame);
    var bestIndex = -1;
    var bestScore = Number.MAX_VALUE;
    var score;
    var i;

    for (i = 0; i < lines.length; i += 1) {
        if (containsNumberV03Test(usedLineIndexes, i)) {
            continue;
        }
        score = getTextLinePairScoreV03Test(textCenter, lines[i], orientation);
        if (score < bestScore) {
            bestScore = score;
            bestIndex = i;
        }
    }
    return bestIndex;
}

function getTextLinePairScoreV03Test(textCenter, line, orientation) {
    var alongDistance = 0;
    var perpendicularDistance;

    if (orientation === "horizontal") {
        perpendicularDistance = Math.abs(textCenter.y - line.centerY);
        if (textCenter.x < line.minX) {
            alongDistance = line.minX - textCenter.x;
        } else if (textCenter.x > line.maxX) {
            alongDistance = textCenter.x - line.maxX;
        }
    } else {
        perpendicularDistance = Math.abs(textCenter.x - line.centerX);
        if (textCenter.y < line.minY) {
            alongDistance = line.minY - textCenter.y;
        } else if (textCenter.y > line.maxY) {
            alongDistance = textCenter.y - line.maxY;
        }
    }
    return (perpendicularDistance * 10) + alongDistance;
}

function containsNumberV03Test(values, targetValue) {
    var i;

    for (i = 0; i < values.length; i += 1) {
        if (values[i] === targetValue) {
            return true;
        }
    }
    return false;
}

function addUniqueTextValueV03Test(values, value) {
    var i;

    for (i = 0; i < values.length; i += 1) {
        if (values[i] === value) {
            return;
        }
    }
    values.push(value);
}

function getPageItemCenterV03Test(item) {
    var bounds = item.geometricBounds;

    return {
        x: (bounds[0] + bounds[2]) / 2,
        y: (bounds[1] + bounds[3]) / 2
    };
}

function getPageItemDisplayNameV03Test(item) {
    var name = "";

    try {
        name = String(item.name || "");
    } catch (error) {
        name = "";
    }
    if (name) {
        return name;
    }
    return "(名称なし)";
}

function isGeneratedDimensionItemV03Test(item) {
    var current = item;
    var name;

    while (current) {
        try {
            if (isGeneratedDimensionNoteV03Test(current.note)) {
                return true;
            }
        } catch (noteError) {
            // Continue with the group name check.
        }

        try {
            if (current.typename === "GroupItem") {
                name = String(current.name || "");
                if (isGeneratedDimensionGroupNameV03Test(name)) {
                    return true;
                }
            }
        } catch (nameError) {
            // Continue checking the parent item.
        }

        try {
            current = current.parent;
            if (!current ||
                    current.typename === "Layer" ||
                    current.typename === "Document") {
                break;
            }
        } catch (parentError) {
            break;
        }
    }
    return false;
}

function isGeneratedDimensionGroupNameV03Test(name) {
    var prefixes = [
        "上側 連立寸法 ",
        "下側 連立寸法 ",
        "左側 連立寸法 ",
        "右側 連立寸法 ",
        "上側 内包寸法 ",
        "下側 内包寸法 ",
        "左側 内包寸法 ",
        "右側 内包寸法 ",
        "上側 横寸法 ",
        "下側 横寸法 ",
        "左側 縦寸法 ",
        "右側 縦寸法 ",
        "スケール表記 "
    ];
    var i;

    for (i = 0; i < prefixes.length; i += 1) {
        if (name.indexOf(prefixes[i]) === 0) {
            return true;
        }
    }
    return false;
}

function detectContainmentV03Test(items) {
    var outerItem = null;
    var outerBounds = null;
    var largestArea = -1;
    var candidateBounds;
    var area;
    var containsAll;
    var innerItems = [];
    var innerBounds;
    var i;
    var j;

    for (i = 0; i < items.length; i += 1) {
        candidateBounds = boundsToObjectV03Test(items[i].geometricBounds);
        containsAll = true;

        for (j = 0; j < items.length; j += 1) {
            if (i !== j &&
                    !boundsContainsV03Test(
                        candidateBounds,
                        boundsToObjectV03Test(items[j].geometricBounds)
                    )) {
                containsAll = false;
                break;
            }
        }

        if (containsAll) {
            area = (candidateBounds.right - candidateBounds.left) *
                (candidateBounds.top - candidateBounds.bottom);
            if (area > largestArea) {
                largestArea = area;
                outerItem = items[i];
                outerBounds = candidateBounds;
            }
        }
    }

    if (!outerItem) {
        return null;
    }

    for (i = 0; i < items.length; i += 1) {
        if (items[i] !== outerItem) {
            innerItems.push(items[i]);
        }
    }
    if (innerItems.length === 0) {
        return null;
    }

    innerBounds = getCombinedGeometricBoundsV03Test(innerItems);
    if (!boundsStrictlyContainsV03Test(outerBounds, innerBounds)) {
        return null;
    }

    return {
        outerItem: outerItem,
        outerBounds: outerBounds,
        innerItems: innerItems,
        innerBounds: innerBounds
    };
}

function boundsContainsV03Test(outerBounds, innerBounds) {
    var tolerance = 0.01;

    return outerBounds.left <= innerBounds.left + tolerance &&
        outerBounds.top >= innerBounds.top - tolerance &&
        outerBounds.right >= innerBounds.right - tolerance &&
        outerBounds.bottom <= innerBounds.bottom + tolerance;
}

function boundsStrictlyContainsV03Test(outerBounds, innerBounds) {
    var tolerance = 0.01;

    return boundsContainsV03Test(outerBounds, innerBounds) &&
        outerBounds.left < innerBounds.left - tolerance &&
        outerBounds.top > innerBounds.top + tolerance &&
        outerBounds.right > innerBounds.right + tolerance &&
        outerBounds.bottom < innerBounds.bottom - tolerance;
}

function sortItemsLeftToRightV03Test(items) {
    items.sort(function (itemA, itemB) {
        var boundsA = itemA.geometricBounds;
        var boundsB = itemB.geometricBounds;

        if (boundsA[0] === boundsB[0]) {
            return boundsB[1] - boundsA[1];
        }
        return boundsA[0] - boundsB[0];
    });
}

function copyPageItemsV03Test(items) {
    var copiedItems = [];
    var i;

    for (i = 0; i < items.length; i += 1) {
        copiedItems.push(items[i]);
    }
    return copiedItems;
}

function getItemsLeftToRightV03Test(items) {
    var sortedItems = copyPageItemsV03Test(items);

    sortItemsLeftToRightV03Test(sortedItems);
    return sortedItems;
}

function sortItemsTopToBottomV03Test(items) {
    items.sort(function (itemA, itemB) {
        var boundsA = itemA.geometricBounds;
        var boundsB = itemB.geometricBounds;

        if (boundsA[1] === boundsB[1]) {
            return boundsA[0] - boundsB[0];
        }
        return boundsB[1] - boundsA[1];
    });
}

function getItemsTopToBottomV03Test(items) {
    var sortedItems = copyPageItemsV03Test(items);

    sortItemsTopToBottomV03Test(sortedItems);
    return sortedItems;
}

function removeCreatedGroupsV03Test(groups) {
    var i;

    for (i = groups.length - 1; i >= 0; i -= 1) {
        try {
            groups[i].remove();
        } catch (error) {
            // Keep the original error message.
        }
    }
}

function removeSelectedItemsV03Test(items) {
    var result = {
        deleted: 0,
        failed: 0
    };
    var i;

    for (i = items.length - 1; i >= 0; i -= 1) {
        try {
            items[i].remove();
            result.deleted += 1;
        } catch (error) {
            result.failed += 1;
        }
    }
    return result;
}

function copySelectionV03Test(selection) {
    var items = [];
    var i;

    if (!selection) {
        return items;
    }
    for (i = 0; i < selection.length; i += 1) {
        items.push(selection[i]);
    }
    return items;
}

function restoreSelectionV03Test(document, items) {
    var i;

    document.selection = null;
    for (i = 0; i < items.length; i += 1) {
        try {
            items[i].selected = true;
        } catch (error) {
            // Ignore unavailable items.
        }
    }
}

function restoreActiveLayerV03Test(document, layer) {
    try {
        if (layer) {
            document.activeLayer = layer;
        }
    } catch (error) {
        // Keep the dimension layer active if the original layer is unavailable.
    }
}

function getCombinedGeometricBoundsV03Test(items) {
    var bounds = boundsToObjectV03Test(items[0].geometricBounds);
    var itemBounds;
    var i;

    for (i = 1; i < items.length; i += 1) {
        itemBounds = items[i].geometricBounds;
        bounds.left = Math.min(bounds.left, itemBounds[0]);
        bounds.top = Math.max(bounds.top, itemBounds[1]);
        bounds.right = Math.max(bounds.right, itemBounds[2]);
        bounds.bottom = Math.min(bounds.bottom, itemBounds[3]);
    }
    return bounds;
}

function boundsToObjectV03Test(bounds) {
    return {
        left: bounds[0],
        top: bounds[1],
        right: bounds[2],
        bottom: bounds[3]
    };
}

function getOrCreateDimensionLayerV03Test(document) {
    var layer;

    try {
        layer = document.layers.getByName(CHAPPY_DIMENSION_STYLE_V03Test.layerName);
    } catch (error) {
        layer = document.layers.add();
        layer.name = CHAPPY_DIMENSION_STYLE_V03Test.layerName;
    }

    if (layer.locked) {
        throw new Error(
            "「" + CHAPPY_DIMENSION_STYLE_V03Test.layerName +
            "」レイヤーのロックを解除してください。"
        );
    }
    if (!layer.visible) {
        layer.visible = true;
    }
    return layer;
}

function createHorizontalDimensionV03Test(group, bounds, label, side, style) {
    var direction = side === "top" ? 1 : -1;
    var edgeY = side === "top" ? bounds.top : bounds.bottom;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var dimensionY = edgeY + (direction * offset);
    var extensionStartY = edgeY + (direction * objectGap);
    var centerX = (bounds.left + bounds.right) / 2;
    var text;

    addLineV03Test(group, bounds.left, dimensionY, bounds.right, dimensionY, style);
    addLineV03Test(
        group,
        bounds.left,
        extensionStartY,
        bounds.left,
        dimensionY,
        style
    );
    addLineV03Test(
        group,
        bounds.right,
        extensionStartY,
        bounds.right,
        dimensionY,
        style
    );
    addEndpointCircleV03Test(group, bounds.left, dimensionY, style);
    addEndpointCircleV03Test(group, bounds.right, dimensionY, style);

    text = addTextV03Test(group, label, style);
    centerPageItemAtV03Test(
        text,
        centerX,
        getHorizontalLabelYV03Test(dimensionY, side, text, textGap)
    );
}

function createChainHorizontalDimensionV03Test(
    group,
    items,
    bounds,
    totalLabel,
    scale,
    roundingMode,
    side,
    style
) {
    var direction = side === "top" ? 1 : -1;
    var edgeY = side === "top" ? bounds.top : bounds.bottom;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var tierGap = millimetersToPointsV03Test(style.tierGapMm);
    var segmentY = edgeY + (direction * offset);
    var totalY = segmentY + (direction * tierGap);
    var extensionStartY = edgeY + (direction * objectGap);
    var itemBounds;
    var segmentLabel;
    var text;
    var endpointXs = [];
    var i;

    for (i = 0; i < items.length; i += 1) {
        itemBounds = boundsToObjectV03Test(items[i].geometricBounds);
        segmentLabel = formatDimensionValueV03Test(
            pointsToMillimetersV03Test(itemBounds.right - itemBounds.left) * scale,
            roundingMode
        );

        addLineV03Test(
            group,
            itemBounds.left,
            segmentY,
            itemBounds.right,
            segmentY,
            style
        );
        addLineV03Test(
            group,
            itemBounds.left,
            extensionStartY,
            itemBounds.left,
            segmentY,
            style
        );
        addLineV03Test(
            group,
            itemBounds.right,
            extensionStartY,
            itemBounds.right,
            segmentY,
            style
        );
        addUniqueEndpointCircleV03Test(
            group,
            endpointXs,
            itemBounds.left,
            segmentY,
            style
        );
        addUniqueEndpointCircleV03Test(
            group,
            endpointXs,
            itemBounds.right,
            segmentY,
            style
        );

        text = addTextV03Test(group, segmentLabel, style);
        centerPageItemAtV03Test(
            text,
            (itemBounds.left + itemBounds.right) / 2,
            getHorizontalLabelYV03Test(segmentY, side, text, textGap)
        );
    }

    addLineV03Test(group, bounds.left, totalY, bounds.right, totalY, style);
    addLineV03Test(group, bounds.left, segmentY, bounds.left, totalY, style);
    addLineV03Test(group, bounds.right, segmentY, bounds.right, totalY, style);
    addEndpointCircleV03Test(group, bounds.left, totalY, style);
    addEndpointCircleV03Test(group, bounds.right, totalY, style);

    text = addTextV03Test(group, totalLabel, style);
    centerPageItemAtV03Test(
        text,
        (bounds.left + bounds.right) / 2,
        getHorizontalLabelYV03Test(totalY, side, text, textGap)
    );
}

function createContainmentHorizontalDimensionV03Test(
    group,
    containment,
    scale,
    roundingMode,
    side,
    style
) {
    var outer = containment.outerBounds;
    var inner = containment.innerBounds;
    var direction = side === "top" ? 1 : -1;
    var outerEdgeY = side === "top" ? outer.top : outer.bottom;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var tierGap = millimetersToPointsV03Test(style.tierGapMm);
    var segmentY = outerEdgeY + (direction * offset);
    var totalY = segmentY + (direction * tierGap);
    var outerStartY = outerEdgeY + (direction * objectGap);
    var points = [outer.left, inner.left, inner.right, outer.right];
    var labels = [
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(inner.left - outer.left) * scale,
            roundingMode
        ),
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(inner.right - inner.left) * scale,
            roundingMode
        ),
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(outer.right - inner.right) * scale,
            roundingMode
        )
    ];
    var totalLabel = formatDimensionValueV03Test(
        pointsToMillimetersV03Test(outer.right - outer.left) * scale,
        roundingMode
    );
    var text;
    var endpointXs = [];
    var i;

    for (i = 0; i < 3; i += 1) {
        addLineV03Test(group, points[i], segmentY, points[i + 1], segmentY, style);
        text = addTextV03Test(group, labels[i], style);
        centerPageItemAtV03Test(
            text,
            (points[i] + points[i + 1]) / 2,
            getHorizontalLabelYV03Test(segmentY, side, text, textGap)
        );
    }

    for (i = 0; i < points.length; i += 1) {
        addLineV03Test(
            group,
            points[i],
            outerStartY,
            points[i],
            segmentY,
            style
        );
        addUniqueEndpointCircleV03Test(
            group,
            endpointXs,
            points[i],
            segmentY,
            style
        );
    }

    addLineV03Test(group, outer.left, totalY, outer.right, totalY, style);
    addLineV03Test(group, outer.left, segmentY, outer.left, totalY, style);
    addLineV03Test(group, outer.right, segmentY, outer.right, totalY, style);
    addEndpointCircleV03Test(group, outer.left, totalY, style);
    addEndpointCircleV03Test(group, outer.right, totalY, style);

    text = addTextV03Test(group, totalLabel, style);
    centerPageItemAtV03Test(
        text,
        (outer.left + outer.right) / 2,
        getHorizontalLabelYV03Test(totalY, side, text, textGap)
    );
}

function getHorizontalLabelYV03Test(lineY, side, text, textGap) {
    if (side === "bottom") {
        return lineY;
    }
    return lineY + (textGap + (text.height / 2));
}

function createVerticalDimensionV03Test(group, bounds, label, side, style) {
    var direction = side === "left" ? -1 : 1;
    var edgeX = side === "left" ? bounds.left : bounds.right;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var dimensionX = edgeX + (direction * offset);
    var extensionStartX = edgeX + (direction * objectGap);
    var centerY = (bounds.top + bounds.bottom) / 2;
    var text;

    addLineV03Test(group, dimensionX, bounds.top, dimensionX, bounds.bottom, style);
    addLineV03Test(
        group,
        dimensionX,
        bounds.top,
        extensionStartX,
        bounds.top,
        style
    );
    addLineV03Test(
        group,
        dimensionX,
        bounds.bottom,
        extensionStartX,
        bounds.bottom,
        style
    );
    addEndpointCircleV03Test(group, dimensionX, bounds.top, style);
    addEndpointCircleV03Test(group, dimensionX, bounds.bottom, style);

    text = addTextV03Test(group, label, style);
    text.rotate(90);
    centerPageItemAtV03Test(
        text,
        dimensionX + (direction * (textGap + (text.width / 2))),
        centerY
    );
}

function createChainVerticalDimensionV03Test(
    group,
    items,
    bounds,
    totalLabel,
    scale,
    roundingMode,
    side,
    style
) {
    var direction = side === "left" ? -1 : 1;
    var edgeX = side === "left" ? bounds.left : bounds.right;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var tierGap = millimetersToPointsV03Test(style.tierGapMm);
    var segmentX = edgeX + (direction * offset);
    var totalX = segmentX + (direction * tierGap);
    var extensionStartX = edgeX + (direction * objectGap);
    var itemBounds;
    var segmentLabel;
    var text;
    var endpointYs = [];
    var i;

    for (i = 0; i < items.length; i += 1) {
        itemBounds = boundsToObjectV03Test(items[i].geometricBounds);
        segmentLabel = formatDimensionValueV03Test(
            pointsToMillimetersV03Test(itemBounds.top - itemBounds.bottom) * scale,
            roundingMode
        );

        addLineV03Test(
            group,
            segmentX,
            itemBounds.top,
            segmentX,
            itemBounds.bottom,
            style
        );
        addLineV03Test(
            group,
            extensionStartX,
            itemBounds.top,
            segmentX,
            itemBounds.top,
            style
        );
        addLineV03Test(
            group,
            extensionStartX,
            itemBounds.bottom,
            segmentX,
            itemBounds.bottom,
            style
        );
        addUniqueEndpointCircleVerticalV03Test(
            group,
            endpointYs,
            segmentX,
            itemBounds.top,
            style
        );
        addUniqueEndpointCircleVerticalV03Test(
            group,
            endpointYs,
            segmentX,
            itemBounds.bottom,
            style
        );

        text = addTextV03Test(group, segmentLabel, style);
        text.rotate(90);
        centerPageItemAtV03Test(
            text,
            segmentX + (direction * (textGap + (text.width / 2))),
            (itemBounds.top + itemBounds.bottom) / 2
        );
    }

    addLineV03Test(group, totalX, bounds.top, totalX, bounds.bottom, style);
    addLineV03Test(group, segmentX, bounds.top, totalX, bounds.top, style);
    addLineV03Test(group, segmentX, bounds.bottom, totalX, bounds.bottom, style);
    addEndpointCircleV03Test(group, totalX, bounds.top, style);
    addEndpointCircleV03Test(group, totalX, bounds.bottom, style);

    text = addTextV03Test(group, totalLabel, style);
    text.rotate(90);
    centerPageItemAtV03Test(
        text,
        totalX + (direction * (textGap + (text.width / 2))),
        (bounds.top + bounds.bottom) / 2
    );
}

function createContainmentVerticalDimensionV03Test(
    group,
    containment,
    scale,
    roundingMode,
    side,
    style
) {
    var outer = containment.outerBounds;
    var inner = containment.innerBounds;
    var direction = side === "left" ? -1 : 1;
    var outerEdgeX = side === "left" ? outer.left : outer.right;
    var offset = millimetersToPointsV03Test(style.offsetMm);
    var objectGap = millimetersToPointsV03Test(style.objectGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var tierGap = millimetersToPointsV03Test(style.tierGapMm);
    var segmentX = outerEdgeX + (direction * offset);
    var totalX = segmentX + (direction * tierGap);
    var outerStartX = outerEdgeX + (direction * objectGap);
    var points = [outer.top, inner.top, inner.bottom, outer.bottom];
    var labels = [
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(outer.top - inner.top) * scale,
            roundingMode
        ),
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(inner.top - inner.bottom) * scale,
            roundingMode
        ),
        formatDimensionValueV03Test(
            pointsToMillimetersV03Test(inner.bottom - outer.bottom) * scale,
            roundingMode
        )
    ];
    var totalLabel = formatDimensionValueV03Test(
        pointsToMillimetersV03Test(outer.top - outer.bottom) * scale,
        roundingMode
    );
    var text;
    var endpointYs = [];
    var i;

    for (i = 0; i < 3; i += 1) {
        addLineV03Test(group, segmentX, points[i], segmentX, points[i + 1], style);
        text = addTextV03Test(group, labels[i], style);
        text.rotate(90);
        centerPageItemAtV03Test(
            text,
            segmentX + (direction * (textGap + (text.width / 2))),
            (points[i] + points[i + 1]) / 2
        );
    }

    for (i = 0; i < points.length; i += 1) {
        addLineV03Test(
            group,
            outerStartX,
            points[i],
            segmentX,
            points[i],
            style
        );
        addUniqueEndpointCircleVerticalV03Test(
            group,
            endpointYs,
            segmentX,
            points[i],
            style
        );
    }

    addLineV03Test(group, totalX, outer.top, totalX, outer.bottom, style);
    addLineV03Test(group, segmentX, outer.top, totalX, outer.top, style);
    addLineV03Test(group, segmentX, outer.bottom, totalX, outer.bottom, style);
    addEndpointCircleV03Test(group, totalX, outer.top, style);
    addEndpointCircleV03Test(group, totalX, outer.bottom, style);

    text = addTextV03Test(group, totalLabel, style);
    text.rotate(90);
    centerPageItemAtV03Test(
        text,
        totalX + (direction * (textGap + (text.width / 2))),
        (outer.top + outer.bottom) / 2
    );
}

function createScaleLabelV03Test(group, bounds, label, style, avoidRightDimension) {
    var scaleGap = millimetersToPointsV03Test(style.scaleGapMm);
    var textGap = millimetersToPointsV03Test(style.textGapMm);
    var text = addTextV03Test(group, label, style);
    var targetLeft = bounds.right + scaleGap;
    var targetCenterY = bounds.bottom + (text.height / 2);
    var currentBounds = text.geometricBounds;
    var currentCenterY = (currentBounds[1] + currentBounds[3]) / 2;

    if (avoidRightDimension) {
        targetCenterY = bounds.bottom - textGap - (text.height / 2);
    }

    text.translate(targetLeft - currentBounds[0], targetCenterY - currentCenterY);
}

function addLineV03Test(group, x1, y1, x2, y2, style) {
    var line = group.pathItems.add();

    line.setEntirePath([[x1, y1], [x2, y2]]);
    line.stroked = true;
    line.strokeWidth = style.strokeWidthPt;
    line.strokeColor = makeBlackColorV03Test();
    line.filled = false;
    return line;
}

function addEndpointCircleV03Test(group, x, y, style) {
    var diameter = millimetersToPointsV03Test(style.endpointDiameterMm);
    var circle = group.pathItems.ellipse(
        y + (diameter / 2),
        x - (diameter / 2),
        diameter,
        diameter
    );

    circle.stroked = false;
    circle.filled = true;
    circle.fillColor = makeBlackColorV03Test();
    return circle;
}

function addUniqueEndpointCircleV03Test(group, endpointXs, x, y, style) {
    var tolerance = 0.01;
    var i;

    for (i = 0; i < endpointXs.length; i += 1) {
        if (Math.abs(endpointXs[i] - x) < tolerance) {
            return;
        }
    }
    endpointXs.push(x);
    addEndpointCircleV03Test(group, x, y, style);
}

function addUniqueEndpointCircleVerticalV03Test(group, endpointYs, x, y, style) {
    var tolerance = 0.01;
    var i;

    for (i = 0; i < endpointYs.length; i += 1) {
        if (Math.abs(endpointYs[i] - y) < tolerance) {
            return;
        }
    }
    endpointYs.push(y);
    addEndpointCircleV03Test(group, x, y, style);
}

function addTextV03Test(group, contents, style) {
    var text = group.textFrames.pointText([0, 0]);
    var attributes;

    text.contents = contents;
    text.textRange.paragraphAttributes.justification = Justification.CENTER;
    attributes = text.textRange.characterAttributes;
    attributes.size = style.fontSizePt;
    attributes.fillColor = makeBlackColorV03Test();

    try {
        attributes.textFont = app.textFonts.getByName(
            style.fontName || CHAPPY_DIMENSION_STYLE_V03Test.preferredFont
        );
    } catch (error) {
        // Keep Illustrator's default font when Kozuka Gothic is unavailable.
    }
    return text;
}

function centerPageItemAtV03Test(item, targetX, targetY) {
    var bounds = item.geometricBounds;
    var currentX = (bounds[0] + bounds[2]) / 2;
    var currentY = (bounds[1] + bounds[3]) / 2;

    item.translate(targetX - currentX, targetY - currentY);
}

function makeBlackColorV03Test() {
    var color = new GrayColor();
    color.gray = 100;
    return color;
}

function millimetersToPointsV03Test(value) {
    return value * 72 / 25.4;
}

function pointsToMillimetersV03Test(value) {
    return value * 25.4 / 72;
}

function formatNumberV03Test(value) {
    var roundedInteger = Math.round(value);
    var roundedTwoDecimals;

    if (Math.abs(value - roundedInteger) < 0.005) {
        return String(roundedInteger);
    }
    roundedTwoDecimals = Math.round(value * 100) / 100;
    return String(roundedTwoDecimals);
}

function formatDimensionValueV03Test(value, roundingMode) {
    if (roundingMode === "floor") {
        return String(Math.floor(value));
    }
    if (roundingMode === "round") {
        return String(Math.round(value));
    }
    return formatNumberV03Test(value);
}

function getRoundingLabelV03Test(roundingMode) {
    if (roundingMode === "floor") {
        return "切り捨て";
    }
    if (roundingMode === "round") {
        return "四捨五入";
    }
    return "なし（小数表示）";
}

function getFontDisplayNameV03Test(fontName) {
    if (fontName === "KozGoPr6N-Regular") {
        return "小塚R";
    }
    return fontName || "Illustrator既定";
}

function openUsageGuideV03Test(guidePath) {
    var guideFile;

    try {
        guideFile = new File(guidePath);
        if (!guideFile.exists) {
            return "エラー: 使用方法ガイドPDFが見つかりません。";
        }
        if (!guideFile.execute()) {
            return "エラー: 使用方法ガイドPDFを開けませんでした。";
        }
        return "使用方法ガイドPDFを開きました。";
    } catch (error) {
        return "エラー: 使用方法ガイドPDFを開けませんでした。 " +
            error.message;
    }
}
