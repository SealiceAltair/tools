(function () {
    "use strict";

    var scalePresetInput = document.getElementById("scalePreset");
    var scaleInput = document.getElementById("scale");
    var magnificationPresetInput =
        document.getElementById("magnificationPreset");
    var magnificationInput = document.getElementById("magnification");
    var fontNameInput = document.getElementById("fontName");
    var fontSizeInput = document.getElementById("fontSize");
    var roundFloorInput = document.getElementById("roundFloor");
    var roundNearestInput = document.getElementById("roundNearest");
    var detectChildrenInput = document.getElementById("detectChildren");
    var detectContainmentInput =
        document.getElementById("detectContainment");
    var showTopInput = document.getElementById("showTop");
    var showBottomInput = document.getElementById("showBottom");
    var showLeftInput = document.getElementById("showLeft");
    var showRightInput = document.getElementById("showRight");
    var showScaleInput = document.getElementById("showScale");
    var deleteSelectedInput = document.getElementById("deleteSelected");
    var createButton = document.getElementById("createDimensions");
    var updateButton = document.getElementById("updateDimensionValues");
    var guideButton = document.getElementById("openUsageGuide");
    var resultElement = document.getElementById("result");
    var baseFontSizePt = 10;
    var isSyncingFontSize = false;

    function showResult(message) {
        resultElement.textContent = message || "(戻り値なし)";
    }

    function formatPointValue(value) {
        var rounded = Math.round(value * 100) / 100;

        if (!isFinite(rounded)) {
            return "";
        }
        return String(rounded)
            .replace(/\.0+$/, "")
            .replace(/(\.\d*[1-9])0+$/, "$1");
    }

    function updateFontSizeFromMagnification() {
        var magnification = Number(magnificationInput.value);

        if (!isFinite(magnification) || magnification <= 0) {
            return;
        }
        isSyncingFontSize = true;
        fontSizeInput.value = formatPointValue(baseFontSizePt * magnification);
        isSyncingFontSize = false;
    }

    function syncBaseFontSizeFromInput() {
        var fontSize = Number(fontSizeInput.value);
        var magnification = Number(magnificationInput.value);

        if (isSyncingFontSize ||
                !isFinite(fontSize) ||
                fontSize <= 0 ||
                !isFinite(magnification) ||
                magnification <= 0) {
            return;
        }
        baseFontSizePt = fontSize / magnification;
    }

    function getRoundingMode() {
        if (roundFloorInput.checked) {
            return "floor";
        }
        if (roundNearestInput.checked) {
            return "round";
        }
        return "none";
    }

    function setRoundingMode(mode) {
        roundFloorInput.checked = mode === "floor";
        roundNearestInput.checked = mode === "round";
    }

    function getDetectionMode() {
        if (detectChildrenInput.checked) {
            return "children";
        }
        if (detectContainmentInput.checked) {
            return "containment";
        }
        return "none";
    }

    function setDetectionMode(mode) {
        detectChildrenInput.checked = mode === "children";
        detectContainmentInput.checked = mode === "containment";
    }

    function saveSettings() {
        try {
            syncBaseFontSizeFromInput();
            localStorage.setItem("chappyDimensionV03TestScale", scaleInput.value);
            localStorage.setItem(
                "chappyDimensionV03TestMagnification",
                magnificationInput.value
            );
            localStorage.setItem(
                "chappyDimensionV03TestFontName",
                fontNameInput.value
            );
            localStorage.setItem(
                "chappyDimensionV03TestBaseFontSize",
                String(baseFontSizePt)
            );
            localStorage.setItem(
                "chappyDimensionV03TestRounding",
                getRoundingMode()
            );
            localStorage.setItem(
                "chappyDimensionV03TestDetection",
                getDetectionMode()
            );
            localStorage.setItem(
                "chappyDimensionV03TestTop",
                showTopInput.checked ? "1" : "0"
            );
            localStorage.setItem(
                "chappyDimensionV03TestBottom",
                showBottomInput.checked ? "1" : "0"
            );
            localStorage.setItem(
                "chappyDimensionV03TestLeft",
                showLeftInput.checked ? "1" : "0"
            );
            localStorage.setItem(
                "chappyDimensionV03TestRight",
                showRightInput.checked ? "1" : "0"
            );
            localStorage.setItem(
                "chappyDimensionV03TestScaleLabel",
                showScaleInput.checked ? "1" : "0"
            );
            localStorage.setItem(
                "chappyDimensionV03TestDeleteSelected",
                deleteSelectedInput.checked ? "1" : "0"
            );
        } catch (error) {
            // Settings persistence is optional in the CEP host.
        }
    }

    function loadCheckboxSetting(key, input) {
        var value = localStorage.getItem(key);

        if (value !== null) {
            input.checked = value === "1";
        }
    }

    function loadSettings() {
        try {
            var savedScale = localStorage.getItem("chappyDimensionV03TestScale");
            var savedMagnification =
                localStorage.getItem("chappyDimensionV03TestMagnification");
            var savedFontName =
                localStorage.getItem("chappyDimensionV03TestFontName");
            var savedBaseFontSize =
                localStorage.getItem("chappyDimensionV03TestBaseFontSize");
            var savedRounding =
                localStorage.getItem("chappyDimensionV03TestRounding");
            var savedDetection =
                localStorage.getItem("chappyDimensionV03TestDetection");

            if (savedScale) {
                scaleInput.value = savedScale;
            }
            if (savedMagnification) {
                magnificationInput.value = savedMagnification;
            }
            if (savedFontName) {
                fontNameInput.value = savedFontName;
            }
            if (savedBaseFontSize &&
                    isFinite(Number(savedBaseFontSize)) &&
                    Number(savedBaseFontSize) > 0) {
                baseFontSizePt = Number(savedBaseFontSize);
            }
            updatePresetFromInput(scalePresetInput, scaleInput);
            updatePresetFromInput(
                magnificationPresetInput,
                magnificationInput
            );
            updateFontSizeFromMagnification();
            setRoundingMode(
                savedRounding === "floor" || savedRounding === "round" ?
                    savedRounding :
                    "none"
            );
            setDetectionMode(
                savedDetection === "children" ||
                    savedDetection === "containment" ?
                    savedDetection :
                    "none"
            );

            loadCheckboxSetting("chappyDimensionV03TestTop", showTopInput);
            loadCheckboxSetting("chappyDimensionV03TestBottom", showBottomInput);
            loadCheckboxSetting("chappyDimensionV03TestLeft", showLeftInput);
            loadCheckboxSetting("chappyDimensionV03TestRight", showRightInput);
            loadCheckboxSetting(
                "chappyDimensionV03TestScaleLabel",
                showScaleInput
            );
            loadCheckboxSetting(
                "chappyDimensionV03TestDeleteSelected",
                deleteSelectedInput
            );
        } catch (error) {
            // Use the defaults when localStorage is unavailable.
        }
    }

    function updatePresetFromInput(presetInput, numberInput) {
        var value = String(Number(numberInput.value));
        var i;

        for (i = 0; i < presetInput.options.length; i += 1) {
            if (presetInput.options[i].value === value) {
                presetInput.selectedIndex = i;
                return;
            }
        }
        presetInput.value = "";
    }

    function applyPreset(presetInput, numberInput) {
        if (presetInput.value) {
            numberInput.value = presetInput.value;
        }
    }

    function handleFloorChange() {
        if (roundFloorInput.checked) {
            roundNearestInput.checked = false;
        }
    }

    function handleNearestChange() {
        if (roundNearestInput.checked) {
            roundFloorInput.checked = false;
        }
    }

    function handleChildrenChange() {
        if (detectChildrenInput.checked) {
            detectContainmentInput.checked = false;
        }
    }

    function handleContainmentChange() {
        if (detectContainmentInput.checked) {
            detectChildrenInput.checked = false;
        }
    }

    function createDimensions() {
        var scale = Number(scaleInput.value);
        var magnification = Number(magnificationInput.value);
        var fontName = fontNameInput.value || "KozGoPr6N-Regular";
        var fontSize = Number(fontSizeInput.value);
        var roundingMode = getRoundingMode();
        var detectionMode = getDetectionMode();
        var showTop = showTopInput.checked;
        var showBottom = showBottomInput.checked;
        var showLeft = showLeftInput.checked;
        var showRight = showRightInput.checked;
        var showScale = showScaleInput.checked;
        var deleteSelected = deleteSelectedInput.checked;
        var script;

        if (!isFinite(scale) || scale <= 0 || Math.floor(scale) !== scale) {
            showResult("スケールには1以上の整数を入力してください。");
            return;
        }
        if (!isFinite(magnification) || magnification <= 0) {
            showResult("拡大率には0より大きい数値を指定してください。");
            return;
        }
        if (!isFinite(fontSize) || fontSize <= 0) {
            showResult("フォントサイズには0より大きい数値を指定してください。");
            return;
        }
        if (!showTop && !showBottom && !showLeft && !showRight && !showScale) {
            showResult("作成する項目を1つ以上チェックしてください。");
            return;
        }
        if (detectionMode === "children" &&
                !showTop && !showBottom && !showLeft && !showRight) {
            showResult("下層レイヤーの連立寸法には上・下・左・右のいずれかが必要です。");
            return;
        }
        if (detectionMode === "containment" &&
                !showTop && !showBottom && !showLeft && !showRight) {
            showResult("内包寸法には上・下・左・右のいずれかが必要です。");
            return;
        }
        if (!window.__adobe_cep__ || !window.__adobe_cep__.evalScript) {
            showResult("CEP APIが見つかりません。IllustratorのCEPパネル内で開いてください。");
            return;
        }

        saveSettings();
        createButton.disabled = true;
        showResult("寸法線を作成しています...");

        script = "createDimensionsV03Test(" +
            String(scale) + "," +
            String(showTop) + "," +
            String(showBottom) + "," +
            String(showLeft) + "," +
            String(showRight) + "," +
            String(showScale) + "," +
            String(magnification) + "," +
            "\"" + detectionMode + "\"," +
            "\"" + roundingMode + "\"," +
            String(deleteSelected) + "," +
            "\"" + escapeForExtendScript(fontName) + "\"," +
            String(fontSize) + ")";

        window.__adobe_cep__.evalScript(script, function (result) {
            createButton.disabled = false;
            showResult(result);
        });
    }

    function escapeForExtendScript(value) {
        return String(value)
            .replace(/\\/g, "\\\\")
            .replace(/"/g, "\\\"")
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n");
    }

    function updateDimensionValues() {
        if (!window.__adobe_cep__ || !window.__adobe_cep__.evalScript) {
            showResult("CEP APIが見つかりません。IllustratorのCEPパネル内で開いてください。");
            return;
        }

        updateButton.disabled = true;
        showResult("選択寸法の数値を更新しています...");

        window.__adobe_cep__.evalScript(
            "updateSelectedDimensionValuesV03Test()",
            function (result) {
                updateButton.disabled = false;
                showResult(result);
            }
        );
    }

    function getUsageGuidePath() {
        var path = window.__adobe_cep__.getSystemPath("extension");

        try {
            path = decodeURI(path);
        } catch (error) {
            // Keep the path returned by CEP when it is not URI encoded.
        }
        path = path.replace(/^file:\/{3}/i, "");
        path = path.replace(/[\\\/]+$/, "");
        return path + "/使用方法ガイド.pdf";
    }

    function openUsageGuide() {
        var guidePath;
        var script;

        if (!window.__adobe_cep__ ||
                !window.__adobe_cep__.evalScript ||
                !window.__adobe_cep__.getSystemPath) {
            showResult("CEP APIが見つかりません。IllustratorのCEPパネル内で開いてください。");
            return;
        }

        guidePath = getUsageGuidePath();
        script = "openUsageGuideV03Test(\"" +
            escapeForExtendScript(guidePath) + "\")";
        guideButton.disabled = true;

        window.__adobe_cep__.evalScript(script, function (result) {
            guideButton.disabled = false;
            showResult(result);
        });
    }

    scalePresetInput.addEventListener("change", function () {
        applyPreset(scalePresetInput, scaleInput);
    });
    scaleInput.addEventListener("input", function () {
        updatePresetFromInput(scalePresetInput, scaleInput);
    });
    magnificationPresetInput.addEventListener("change", function () {
        applyPreset(magnificationPresetInput, magnificationInput);
        updateFontSizeFromMagnification();
    });
    magnificationInput.addEventListener("input", function () {
        updatePresetFromInput(
            magnificationPresetInput,
            magnificationInput
        );
        updateFontSizeFromMagnification();
    });
    fontSizeInput.addEventListener("input", syncBaseFontSizeFromInput);
    roundFloorInput.addEventListener("change", handleFloorChange);
    roundNearestInput.addEventListener("change", handleNearestChange);
    detectChildrenInput.addEventListener("change", handleChildrenChange);
    detectContainmentInput.addEventListener(
        "change",
        handleContainmentChange
    );
    createButton.addEventListener("click", createDimensions);
    updateButton.addEventListener("click", updateDimensionValues);
    guideButton.addEventListener("click", openUsageGuide);
    loadSettings();
}());
